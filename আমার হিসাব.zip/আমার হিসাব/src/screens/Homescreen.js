import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import BalanceSummary from '../components/BalanceSummary';
import TransactionList from '../components/TransactionList';
import { getTransactions } from '../utils/storage';

export default function HomeScreen() {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    loadTransactions();
  }, []);

  const loadTransactions = async () => {
    const loadedTransactions = await getTransactions();
    setTransactions(loadedTransactions);
  };

  return (
    <View style={styles.container}>
      <BalanceSummary transactions={transactions} />
      <TransactionList transactions={transactions} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
});