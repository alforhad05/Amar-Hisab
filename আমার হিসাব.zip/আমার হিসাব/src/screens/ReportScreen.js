import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { PieChart } from 'react-native-chart-kit';
import { getTransactions } from '../utils/storage';

export default function ReportScreen() {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    loadTransactions();
  }, []);

  const loadTransactions = async () => {
    const loadedTransactions = await getTransactions();
    setTransactions(loadedTransactions);
  };

  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const chartData = [
    { name: 'আয়', population: totalIncome, color: 'rgba(131, 167, 234, 1)', legendFontColor: '#7F7F7F', legendFontSize: 15 },
    { name: 'ব্যয়', population: totalExpense, color: '#F00', legendFontColor: '#7F7F7F', legendFontSize: 15 },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>আয়-ব্যয় রিপোর্ট</Text>
      <PieChart
        data={chartData}
        width={300}
        height={200}
        chartConfig={{
          backgroundColor: '#e26a00',
          backgroundGradientFrom: '#fb8c00',
          backgroundGradientTo: '#ffa726',
          decimalPlaces: 2,
          color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
          style: {
            borderRadius: 16
          }
        }}
        accessor="population"
        backgroundColor="transparent"
        paddingLeft="15"
      />
      <View style={styles.summaryContainer}>
        <Text style={styles.summaryText}>মোট আয়: ৳{totalIncome.toFixed(2)}</Text>
        <Text style={styles.summaryText}>মোট ব্যয়: ৳{totalExpense.toFixed(2)}</Text>
        <Text style={styles.summaryText}>নেট ব্যালেন্স: ৳{(totalIncome - totalExpense).toFixed(2)}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  summaryContainer: {
    marginTop: 20,
  },
  summaryText: {
    fontSize: 18,
    marginBottom: 10,
  },
});