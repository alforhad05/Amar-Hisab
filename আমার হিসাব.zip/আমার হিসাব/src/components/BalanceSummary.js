import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function BalanceSummary({ transactions }) {
  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const balance = totalIncome - totalExpense;

  return (
    <View style={styles.container}>
      <Text style={styles.balanceText}>মোট ব্যালেন্স: ৳{balance.toFixed(2)}</Text>
      <View style={styles.row}>
        <Text style={styles.incomeText}>আয়: ৳{totalIncome.toFixed(2)}</Text>
        <Text style={styles.expenseText}>ব্যয়: ৳{totalExpense.toFixed(2)}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f0f0f0',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
  },
  balanceText: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  incomeText: {
    fontSize: 18,
    color: 'green',
  },
  expenseText: {
    fontSize: 18,
    color: 'red',
  },
});