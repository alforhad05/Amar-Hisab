import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

export default function TransactionList({ transactions }) {
  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <View>
        <Text style={styles.description}>{item.description}</Text>
        <Text style={styles.date}>{new Date(item.date).toLocaleDateString('bn-BD')}</Text>
      </View>
      <Text style={[styles.amount, item.type === 'income' ? styles.income : styles.expense]}>
        ৳{item.amount.toFixed(2)}
      </Text>
    </View>
  );

  return (
    <FlatList
      data={transactions}
      renderItem={renderItem}
      keyExtractor={item => item.id}
      style={styles.list}
    />
  );
}

const styles = StyleSheet.create({
  list: {
    flex: 1,
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  description: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  date: {
    fontSize: 12,
    color: '#888',
  },
  amount: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  income: {
    color: 'green',
  },
  expense: {
    color: 'red',
  },
});