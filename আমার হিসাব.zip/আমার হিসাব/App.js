import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import HomeScreen from './src/screens/HomeScreen';
import AddTransactionScreen from './src/screens/AddTransactionScreen';
import ReportScreen from './src/screens/ReportScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'হোম') {
              iconName = focused ? 'home' : 'home-outline';
            } else if (route.name === 'যোগ করুন') {
              iconName = focused ? 'add-circle' : 'add-circle-outline';
            } else if (route.name === 'রিপোর্ট') {
              iconName = focused ? 'bar-chart' : 'bar-chart-outline';
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
        })}
        tabBarOptions={{
          activeTintColor: 'tomato',
          inactiveTintColor: 'gray',
        }}
      >
        <Tab.Screen name="হোম" component={HomeScreen} />
        <Tab.Screen name="যোগ করুন" component={AddTransactionScreen} />
        <Tab.Screen name="রিপোর্ট" component={ReportScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}